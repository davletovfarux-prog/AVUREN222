AUVREN 222 — statik saytning birinchi versiyasi.
index.html faylini brauzerda ochish mumkin.
Saytdagi buyurtma tugmalari https://t.me/AUVREN222 kanaliga olib boradi.
Rasmlar internetdan yuklanadi; rasmlarni ko‘rish uchun internet kerak.
Mahsulot rasmlari hozircha namuna, real katalog va narxlar Telegramda tasdiqlanadi.
